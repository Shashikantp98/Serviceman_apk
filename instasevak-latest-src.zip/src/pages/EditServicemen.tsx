import { useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import type { SubmitHandler, Resolver } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import Input from "../components/inputs/input";
import { useNavigate } from "react-router-dom";
import ApiService from "../services/api";
import MultiSelect from "../components/inputs/MultiSelect";
import FileInput from "../components/inputs/FileInput";
import { toast } from "react-toastify";
import GooglePlacesAutocomplete from "../components/GooglePlacesAutocomplete";
import { GOOGLE_API_KEY } from "../config";
import { useLoadScript } from "@react-google-maps/api";
import CommonHeader from "../components/CommonHeader";
import { ChevronDown, ChevronUp, Paperclip } from "react-feather";
// import SectionLoader from "../components/SectionLoader";
import { useSectionLoader } from "../utils/useSectionLoader";
import { useAuth } from "../contexts/AuthContext";

// ✅ Define TypeScript interface
interface Address {
  street_1: string;
  city: string;
  state: string;
  country: string;
  zip: string;
}

interface Bank {
  account_name: string;
  bank_name: string;
  account_number: string;
  ifsc_code: string;
  upi_id: string;
}

interface FormValues {
  fname: string;
  lname: string;
  email: string;
  //   country_code: string;
  //   phone_number: string;
  category_ids: string[];
  service_ids: string[];
  address: Address;
  home_address: Address;
  bank: Bank;
  profile_image: FileList;
  serviceman_document: FileList;
  serviceman_document_2: FileList | string;
  serviceman_document_3: FileList | string;
}

// ✅ Define Yup validation schema
const validationSchema = Yup.object().shape({
  fname: Yup.string().required("First name is required"),
  lname: Yup.string(),
  email: Yup.string()
    .nullable()
    .trim()
    .test(
      "is-valid-email",
      "Invalid email",
      (value) => !value || Yup.string().email().isValidSync(value)
    ),
  // country_code: Yup.string().required("Country code is required"),
  // phone_number: Yup.string()
  //   .matches(/^[0-9]{10}$/, "Phone number must be 10 digits")
  //   .required("Phone number is required"),

  category_ids: Yup.array().of(Yup.string()).notRequired(),

  service_ids: Yup.array()
    .of(Yup.string().required("Invalid service ID"))
    .min(1, "At least one service required")
    .required("Service IDs are required"),

  address: Yup.object().shape({
    street_1: Yup.string().required("Street is required"),
    city: Yup.string().required("City is required"),
    state: Yup.string().required("State is required"),
    country: Yup.string().required("Country is required"),
    zip: Yup.string().required("Zip code is required"),
  }),

  home_address: Yup.object().shape({
    street_1: Yup.string().required("Street is required"),
    city: Yup.string().required("City is required"),
    state: Yup.string().required("State is required"),
    country: Yup.string().required("Country is required"),
    zip: Yup.string().required("Zip code is required"),
  }),

  bank: Yup.object({
    upi_id: Yup.string()
      .trim()
      .test("isValidUPI", "Invalid UPI ID format", (value) => {
        if (!value) return true;
        return /^[\w.-]{2,}@[\w.-]{2,}$/.test(value);
      })
      .nullable(),

    account_name: Yup.string().notRequired(),
    bank_name: Yup.string().notRequired(),

    account_number: Yup.string()
      .notRequired()
      .nullable()
      .matches(/^[0-9]{9,18}$/, { message: "Account number must be 9–18 digits", excludeEmptyString: true }),

    ifsc_code: Yup.string()
      .notRequired()
      .nullable()
      .matches(/^[A-Za-z]{4}\d{7}$/, { message: "Invalid IFSC format", excludeEmptyString: true }),
  }).notRequired(),

  profile_image: Yup.mixed<FileList | string>()
    .test("fileOrUrl", "Profile image is required", (value) => {
      // ✅ Accept if we already have a file URL string from API
      if (typeof value === "string" && value.trim() !== "") return true;

      // ✅ Accept if user uploaded a valid FileList
      if (value instanceof FileList && value.length > 0) return true;

      // ❌ Otherwise, invalid
      return false;
    })
    .test("fileType", "Invalid profile image type", (value) => {
      // Skip file type validation if it's an existing URL string
      if (typeof value === "string") return true;

      if (!value || value.length === 0) return false;
      const file = value[0];
      const allowedTypes = ["application/pdf", "image/jpeg", "image/png"];
      return allowedTypes.includes(file.type);
    }),

  serviceman_document: Yup.mixed<FileList | string>()
    .test("fileOrUrl", "Document is required", (value) => {
      // ✅ Accept if we already have a file URL string from API
      if (typeof value === "string" && value.trim() !== "") return true;

      // ✅ Accept if user uploaded a valid FileList
      if (value instanceof FileList && value.length > 0) return true;

      // ❌ Otherwise, invalid
      return false;
    })
    .test("fileType", "Invalid document type", (value) => {
      // Skip file type validation if it's an existing URL string
      if (typeof value === "string") return true;

      if (!value || value.length === 0) return false;
      const file = value[0];
      const allowedTypes = ["application/pdf", "image/jpeg", "image/png"];
      return allowedTypes.includes(file.type);
    }),

  serviceman_document_2: Yup.mixed<FileList | string>()
    .notRequired()
    .test("fileOrUrl2", "Invalid document", (value) => {
      if (!value) return true;
      if (typeof value === "string" && value.trim() !== "") return true;
      if (value instanceof FileList && value.length > 0) return true;
      return false;
    })
    .test("fileType2", "Invalid document type", (value) => {
      if (typeof value === "string") return true;
      if (!value || value.length === 0) return true;
      const file = value[0];
      const allowedTypes = ["application/pdf", "image/jpeg", "image/png"];
      return allowedTypes.includes(file.type);
    }),

  serviceman_document_3: Yup.mixed<FileList | string>()
    .notRequired()
    .test("fileOrUrl3", "Invalid document", (value) => {
      if (!value) return true;
      if (typeof value === "string" && value.trim() !== "") return true;
      if (value instanceof FileList && value.length > 0) return true;
      return false;
    })
    .test("fileType3", "Invalid document type", (value) => {
      if (typeof value === "string") return true;
      if (!value || value.length === 0) return true;
      const file = value[0];
      const allowedTypes = ["application/pdf", "image/jpeg", "image/png"];
      return allowedTypes.includes(file.type);
    }),
});

const EditServicemen = () => {
  const navigate = useNavigate();
  const { latitude, longitude } = useAuth();
  const [openSection, setOpenSection] = useState<
    "general" | "bank" | "verification" | "none"
  >("general");
  const [paymentType, setPaymentType] = useState<"upi" | "bank">("bank");

  // Loader for edit serviceman
  const servicemanEditLoader = useSectionLoader("serviceman-edit");
  // Tracks existing document _ids to send in document_ids payload
  const [documentIds, setDocumentIds] = useState<string[]>([]);
  // Holds pre-existing service_ids to restore after services list loads (avoids reset wipe)
  const pendingServiceIds = useRef<string[] | null>(null);

  const getProfileDetails = () => {
    servicemanEditLoader.setLoading(true);
    ApiService.post("/servicemen/getServicemenDetails")
      .then((res: any) => {
        console.log(res);
        setValue("fname", res.data.fname);
        setValue("lname", res.data.lname);
        setValue("email", res.data.email);
        if (res.data.service_location) {
          setValue("address", res.data.service_location);
        }
        setValue("home_address", res.data.home_address);
        setValue("bank", res.data.bank_details);
        // Store service_ids in ref — will be restored after the services list loads
        if (Array.isArray(res.data.services)) {
          pendingServiceIds.current = res.data.services.map((s: any) => s._id || s.service_id || s);
        }
        // Pre-select categories from API response
        if (Array.isArray(res.data.categories) && res.data.categories.length > 0) {
          const category_ids = res.data.categories.map((c: any) => c._id || c.category_id || c);
          setValue("category_ids", category_ids);
          // category_ids being set will trigger the services useEffect which restores service_ids
        } else if (pendingServiceIds.current?.length) {
          // No categories in response — set service_ids directly
          setValue("service_ids", pendingServiceIds.current);
          pendingServiceIds.current = null;
        }
        if (res.data.documents && res.data.documents.length > 0) {
          const docs = res.data.documents;
          // Track all existing document _ids (handles both `_id` and `id` field names)
          setDocumentIds(
            docs.map((d: any) => d._id || d.id || "").filter(Boolean)
          );
          // Load each doc into its corresponding field by index
          if (docs[0]?.file_url) setValue("serviceman_document", docs[0].file_url);
          if (docs[1]?.file_url) setValue("serviceman_document_2", docs[1].file_url);
          if (docs[2]?.file_url) setValue("serviceman_document_3", docs[2].file_url);
        }
        if (res.data.profile_image) {
          setValue("profile_image", res.data.profile_image);
        }
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        servicemanEditLoader.setLoading(false);
      })
  };
  useEffect(() => {
    getProfileDetails();
  }, []);
  const [loading, setLoading] = useState(false);
  const {
    // register,
    handleSubmit,
    control,
    setValue,
    getValues,
    formState: { errors },
    watch,
  } = useForm<FormValues>({
    resolver: yupResolver(validationSchema) as Resolver<FormValues>,

    defaultValues: {
      category_ids: [],
      service_ids: [],
      address: { street_1: "", city: "", state: "", country: "", zip: "" },
      home_address: { street_1: "", city: "", state: "", country: "", zip: "" },
      bank: {
        account_name: "",
        bank_name: "",
        account_number: "",
        ifsc_code: "",
        upi_id: "",
      },
    },
  });
  console.log(errors);
  // Previews for profile image and document (accepts FileList or existing URL string)
  const [profilePreview, setProfilePreview] = useState<string | null>(null);
  const [docPreview, setDocPreview] = useState<string | null>(null);
  const [docPreview2, setDocPreview2] = useState<string | null>(null);
  const [docPreview3, setDocPreview3] = useState<string | null>(null);

  const watchedProfile = watch("profile_image") as FileList | string | undefined;
  const watchedDoc = watch("serviceman_document") as FileList | string | undefined;
  const watchedDoc2 = watch("serviceman_document_2") as FileList | string | undefined;
  const watchedDoc3 = watch("serviceman_document_3") as FileList | string | undefined;

  useEffect(() => {
    let url: string | null = null;
    if (!watchedProfile) {
      setProfilePreview(null);
      return;
    }

    if (typeof watchedProfile === "string") {
      // existing URL from API
      setProfilePreview(watchedProfile as string);
      return;
    }

    // It's a FileList
    if (watchedProfile instanceof FileList && watchedProfile.length > 0) {
      url = URL.createObjectURL(watchedProfile[0]);
      setProfilePreview(url);
    } else {
      setProfilePreview(null);
    }

    return () => {
      if (url) {
        URL.revokeObjectURL(url);
      }
    };
  }, [watchedProfile]);

  useEffect(() => {
    let url: string | null = null;
    if (!watchedDoc) {
      setDocPreview(null);
      return;
    }

    if (typeof watchedDoc === "string") {
      setDocPreview(watchedDoc as string);
      return;
    }

    if (watchedDoc instanceof FileList && watchedDoc.length > 0) {
      url = URL.createObjectURL(watchedDoc[0]);
      setDocPreview(url);
    } else {
      setDocPreview(null);
    }

    return () => {
      if (url) URL.revokeObjectURL(url);
    };
  }, [watchedDoc]);

  useEffect(() => {
    let url: string | null = null;
    if (!watchedDoc2) { setDocPreview2(null); return; }
    if (typeof watchedDoc2 === "string") { setDocPreview2(watchedDoc2); return; }
    if (watchedDoc2 instanceof FileList && watchedDoc2.length > 0) {
      url = URL.createObjectURL(watchedDoc2[0]);
      setDocPreview2(url);
    } else {
      setDocPreview2(null);
    }
    return () => { if (url) URL.revokeObjectURL(url); };
  }, [watchedDoc2]);

  useEffect(() => {
    let url: string | null = null;
    if (!watchedDoc3) { setDocPreview3(null); return; }
    if (typeof watchedDoc3 === "string") { setDocPreview3(watchedDoc3); return; }
    if (watchedDoc3 instanceof FileList && watchedDoc3.length > 0) {
      url = URL.createObjectURL(watchedDoc3[0]);
      setDocPreview3(url);
    } else {
      setDocPreview3(null);
    }
    return () => { if (url) URL.revokeObjectURL(url); };
  }, [watchedDoc3]);

  const onSubmit: SubmitHandler<FormValues> = (data) => {
    const formData = new FormData();

    // Scalar fields
    if (data.fname) formData.append("fname", data.fname);
    if (data.lname) formData.append("lname", data.lname);
    if (data.email) formData.append("email", data.email);
    if (data.service_ids?.length) formData.append("service_ids", JSON.stringify(data.service_ids));
    if (data.address) formData.append("address", JSON.stringify(data.address));
    if (data.home_address) formData.append("home_address", JSON.stringify(data.home_address));
    if (data.bank) {
      // Strip extra API-response fields (_id, serviceman_id, etc.) before sending
      const { account_name, bank_name, account_number, ifsc_code, upi_id, country } = data.bank as any;
      const cleanBank = { account_name, bank_name, account_number, ifsc_code, upi_id, country };
      formData.append("bank", JSON.stringify(cleanBank));
    }

    // Profile image
    if (data.profile_image instanceof FileList && data.profile_image[0]) {
      formData.append("profile_image", data.profile_image[0]);
    }

    // Documents — read directly from form store to bypass any Yup mixed() cast
    // that could silently drop FileList values for notRequired() fields.
    const rawDocs = getValues(["serviceman_document", "serviceman_document_2", "serviceman_document_3"]);
    const docSlots: { field: FileList | string | undefined; idIndex: number }[] = [
      { field: rawDocs[0] as FileList | string | undefined, idIndex: 0 },
      { field: rawDocs[1] as FileList | string | undefined, idIndex: 1 },
      { field: rawDocs[2] as FileList | string | undefined, idIndex: 2 },
    ];
    console.log("📄 Doc slots at submit:", docSlots.map(s => ({
      idIndex: s.idIndex,
      isFileList: s.field instanceof FileList,
      fileCount: s.field instanceof FileList ? s.field.length : "n/a",
      isString: typeof s.field === "string",
    })));
    const uploadedIds: string[] = [];
    docSlots.forEach(({ field, idIndex }) => {
      if (field instanceof FileList && field[0]) {
        formData.append("serviceman_document", field[0]);
        if (documentIds[idIndex]) uploadedIds.push(documentIds[idIndex]);
      }
    });
    if (uploadedIds.length > 0) {
      formData.append("document_ids", JSON.stringify(uploadedIds));
    }

    console.log("✅ Final FormData (to send via API):", data);
    setLoading(true);
    ApiService.post("/servicemen/editServicemen", formData, {
      timeout: 120000, // 2 minutes — needed for file uploads on mobile
    })
      .then((res: any) => {
        console.log(res);
        setLoading(false);
        toast.success(res.message);
        navigate(-1);
      })
      .catch((err: any) => {
        console.log(err);
        setLoading(false);
        const msg =
          err?.response?.data?.message ||
          (err?.code === "ECONNABORTED" ? "Upload timed out. Please try again." : "Something went wrong.");
        toast.error(msg);
      });
  };
  const [serviceList, setserviceList] = useState<any>([]);
  const [categoryList, setCategoryList] = useState<any[]>([]);
  const selectedCategoryIds = watch("category_ids") ?? [];
  const selectedCategoriesKey = JSON.stringify(selectedCategoryIds);

  // Fetch all categories on mount
  useEffect(() => {
    ApiService.post(`/user/getAllCategoryList`, {
      latitude: Number(latitude),
      longitude: Number(longitude),
      filters: { search: "" },
      pagination: { page: 1, pageSize: 50 },
    })
      .then((res: any) => {
        setCategoryList(res.data?.list || []);
      })
      .catch(() => {});
  }, [latitude, longitude]);

  // Fetch services filtered by selected categories
  useEffect(() => {
    if (!selectedCategoryIds.length) {
      setserviceList([]);
      return;
    }
    ApiService.post(`/servicemen/listServicesForServiceman`, {
       filters: { category_id: selectedCategoryIds } ,
    })
      .then((res: any) => {
        const list = res.data?.list || [];
        setserviceList(list);
        if (pendingServiceIds.current !== null) {
          // Restore pre-existing selections on initial load
          setValue("service_ids", pendingServiceIds.current);
          pendingServiceIds.current = null;
        } else {
          // User changed categories — keep selections still valid in the new list
          const newIds = new Set(list.map((s: any) => s.service_id));
          const current = getValues("service_ids") || [];
          setValue("service_ids", current.filter((id: string) => newIds.has(id)));
        }
      })
      .catch(() => {});
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedCategoriesKey]);

  const serviceListOptions = serviceList.map((service: any) => ({
    label: service.service_name,
    value: service.service_id,
  }));

  const categoryListOptions = categoryList.map((cat: any) => ({
    label: cat.category_name,
    value: cat.category_id || cat._id,
  }));
  const handleAddressSelect = (address: any) => {
    console.log("Selected Address:", address);

    // Set main address field
    setValue("home_address.street_1", address.fullAddress, {
      shouldValidate: true,
      shouldDirty: true,
    });

    // Set individual fields
    if (address.city) {
      setValue("home_address.city", address.city, {
        shouldValidate: true,
        shouldDirty: true,
      });
    }
    if (address.state) {
      setValue("home_address.state", address.state, {
        shouldValidate: true,
        shouldDirty: true,
      });
    }
    if (address.postalCode) {
      setValue("home_address.zip", address.postalCode, {
        shouldValidate: true,
        shouldDirty: true,
      });
    }
    if (address.country) {
      setValue("home_address.country", address.country, {
        shouldValidate: true,
        shouldDirty: true,
      });
    }
  };
  useEffect(() => {
    if (!errors) return;

    if (
      errors.fname ||
      errors.lname ||
      errors.email ||
      errors.service_ids ||
      errors.profile_image ||
      errors.home_address
    ) {
      setOpenSection("general");
    } else if (
      errors.bank?.upi_id ||
      errors.bank?.account_name ||
      errors.bank?.bank_name ||
      errors.bank?.account_number ||
      errors.bank?.ifsc_code ||
      errors.bank?.message
    ) {
      setOpenSection("bank");
    } else if (errors.address || errors.serviceman_document) {
      setOpenSection("verification");
    }
  }, [errors]);
  const handleAddressSelect2 = (address: any) => {
    console.log("Selected Address:", address);

    // Set main address field
    setValue("address.street_1", address.fullAddress, {
      shouldValidate: true,
      shouldDirty: true,
    });

    // Set individual fields
    if (address.city) {
      setValue("address.city", address.city, {
        shouldValidate: true,
        shouldDirty: true,
      });
    }
    if (address.state) {
      setValue("address.state", address.state, {
        shouldValidate: true,
        shouldDirty: true,
      });
    }
    if (address.postalCode) {
      setValue("address.zip", address.postalCode, {
        shouldValidate: true,
        shouldDirty: true,
      });
    }
    if (address.country) {
      setValue("address.country", address.country, {
        shouldValidate: true,
        shouldDirty: true,
      });
    }
  };
  const { isLoaded } = useLoadScript({
    googleMapsApiKey: GOOGLE_API_KEY,
    libraries: ["places"],
  });
  if (!isLoaded) return <p>Loading...</p>;
  return (
    <>
      <CommonHeader />
      <div className="container mb-8 main-content-service">
        {servicemanEditLoader.loading && (
          <div className="full-page-loader">
            <div className="loader-spinner"></div>
            <p>Loading Profile details...</p>
          </div>
        )}
        <div className="row pt-4">
          <div className="col-12 text-center pb-3">
            <h6 className="head4">Edit Profile</h6>
          </div>
        </div>
        {/* Accordion Sections */}
        <div className="row">
          <div className="col-12">
 <div className="accordion">
          {/* 1. General Info */}
          <div className="accordion-item mb-3 border rounded p-3">
            <div
              className="d-flex justify-content-between align-items-center"
              onClick={() =>
                setOpenSection(openSection === "general" ? "none" : "general")
              }
              style={{ cursor: "pointer" }}
            >
              <h6 className="m-0">General Info</h6>
              {openSection === "general" ? <ChevronUp /> : <ChevronDown />}
            </div>
            {openSection === "general" && (
              <div className="row px-3 pt-3">
                <div className="col-12 pt-3">
                  <label className="lbl2">First Name</label>
                  <Input
                    control={control}
                    name="fname"
                    label=""
                    type="text"
                    placeholder="Enter First Name"
                    inputMode="text"
                    error={errors.fname?.message as string}
                    disabled={loading}
                  />
                </div>
                <div className="col-12 pt-3">
                  <label className="lbl2">Last Name</label>
                  <Input
                    control={control}
                    name="lname"
                    label=""
                    type="text"
                    placeholder="Enter Last Name"
                    inputMode="text"
                    error={errors.lname?.message as string}
                    disabled={loading}
                  />
                </div>
                <div className="col-12 pt-3">
                  <label className="lbl2">Email</label>
                  <Input
                    control={control}
                    name="email"
                    label=""
                    type="text"
                    placeholder="Enter Email"
                    inputMode="text"
                    error={errors.email?.message as string}
                    disabled={loading}
                  />
                </div>
                <div className="col-12 pt-3">
                  <label className="lbl2">Select Category</label>
                  <MultiSelect
                    control={control}
                    name="category_ids"
                    label=""
                    options={categoryListOptions}
                    disabled={loading}
                  />
                </div>
                <div className="col-12 pt-3">
                  <label className="lbl2">Service Type</label>
                  <div
                    onClick={() => {
                      if (!selectedCategoryIds.length) {
                        toast.info("Please select a category first");
                      }
                    }}
                  >
                    <MultiSelect
                      control={control}
                      name="service_ids"
                      label=""
                      options={serviceListOptions}
                      error={errors.service_ids?.message as string}
                      disabled={loading || !selectedCategoryIds.length}
                    />
                  </div>
                  {!selectedCategoryIds.length && (
                    <p className="text-muted font-12 mt-1">
                      ⚠️ Select a category above to load available services.
                    </p>
                  )}
                </div>
                <div className="col-12 pt-3">
                  <FileInput
                    label="Upload Profile Image"
                    name="profile_image"
                    control={control}
                    error={errors.profile_image?.message as string}
                    openCamera
                    captureMode="user"
                    accept="image/*"
                  />
                  <div className="col-12 pt-2" style={{ textAlign: "center" }}>
                    {profilePreview && (
                      <img
                        style={{ height: "120px", width: "120px", borderRadius: 8 }}
                        src={profilePreview}
                        alt="Profile preview"
                        className="img-fluid"
                      />
                    )}
                  </div>
                </div>
                <div className="col-12 pt-3">
                  <label className="lbl2">Home Address</label>
                  <GooglePlacesAutocomplete
                    control={control}
                    name="home_address.street_1"
                    onSelect={handleAddressSelect}
                    label=""
                    error={errors.home_address?.street_1?.message?.toString()}
                  />
                </div>
              </div>
            )}
          </div>

          {/* 2. Bank Info */}
          <div className="accordion-item mb-3 border rounded p-3">
            <div
              className="d-flex justify-content-between align-items-center"
              onClick={() =>
                setOpenSection(openSection === "bank" ? "none" : "bank")
              }
              style={{ cursor: "pointer" }}
            >
              <h6 className="m-0">Bank Info</h6>
              {openSection === "bank" ? <ChevronUp /> : <ChevronDown />}
            </div>
            {openSection === "bank" && (
              <div className="mt-3">
                <div className="row">
                  <div className="col-12 pt-3">
                    <label className="lbl2 d-block mb-2">Select Payment Method</label>
                    <div className="d-flex gap-4">
                      <div className="form-check">
                        <input
                          type="radio"
                          className="form-check-input"
                          id="upiOption"
                          name="payment_type"
                          checked={paymentType === "upi"}
                          onChange={() => setPaymentType("upi")}
                        />
                        <label htmlFor="upiOption" className="form-check-label font-14">UPI ID</label>
                      </div>
                      <div className="form-check">
                        <input
                          type="radio"
                          className="form-check-input"
                          id="bankOption"
                          name="payment_type"
                          checked={paymentType === "bank"}
                          onChange={() => setPaymentType("bank")}
                        />
                        <label htmlFor="bankOption" className="form-check-label font-14">Bank Account</label>
                      </div>
                    </div>
                  </div>
                  {errors.bank?.message && (
                    <div className="col-12 pt-3">
                      <div className="alert alert-danger py-2">{errors.bank?.message}</div>
                    </div>
                  )}
                  {paymentType === "upi" && (
                    <div className="col-12 pt-3">
                      <Input
                        label="UPI ID"
                        control={control}
                        name="bank.upi_id"
                        type="text"
                        placeholder="example@bank"
                        error={errors.bank?.upi_id?.message as string}
                      />
                      <p className="text-muted font-12 mt-2">Enter your valid UPI handle (e.g. name@bank)</p>
                    </div>
                  )}
                  {paymentType === "bank" && (
                    <div className="col-12 pt-3">
                      <Input
                        label="Account Name"
                        control={control}
                        name="bank.account_name"
                        type="text"
                        placeholder="Enter Account Name"
                        error={errors.bank?.account_name?.message as string}
                      />
                      <Input
                        label="Bank Name"
                        control={control}
                        name="bank.bank_name"
                        type="text"
                        placeholder="Enter Bank Name"
                        error={errors.bank?.bank_name?.message as string}
                      />
                      <Input
                        label="Account Number"
                        control={control}
                        name="bank.account_number"
                        type="text"
                        inputMode="numeric"
                        placeholder="Enter Account Number"
                        error={errors.bank?.account_number?.message as string}
                      />
                      <Input
                        label="IFSC Code"
                        control={control}
                        name="bank.ifsc_code"
                        type="text"
                        placeholder="Enter IFSC Code"
                        error={errors.bank?.ifsc_code?.message as string}
                      />
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* 3. Verification Info */}
          <div className="accordion-item mb-3 border rounded p-3">
            <div
              className="d-flex justify-content-between align-items-center"
              onClick={() =>
                setOpenSection(openSection === "verification" ? "none" : "verification")
              }
              style={{ cursor: "pointer" }}
            >
              <h6 className="m-0">Verification Info</h6>
              {openSection === "verification" ? <ChevronUp /> : <ChevronDown />}
            </div>
            {openSection === "verification" && (
              <div className="mt-3">
                <div className="col-12 pt-3">
                  <label className="lbl2">Service Address</label>
                  <GooglePlacesAutocomplete
                    control={control}
                    name="address.street_1"
                    onSelect={handleAddressSelect2}
                    label=""
                    error={errors.address?.street_1?.message?.toString()}
                  />
                </div>
                <div className="col-12 pt-3">
                  <FileInput
                    label="Upload Aadhar Card (Front)"
                    name="serviceman_document"
                    control={control}
                    error={errors.serviceman_document?.message as string}
                  />
                  <div className="col-12 pt-2" style={{ textAlign: "center" }}>
                    {docPreview && (
                      /\.(jpe?g|png|gif|webp|bmp|pdf)$/i.test(docPreview) ? (
                        <img
                          style={{ height: "120px", width: "240px", objectFit: "contain" }}
                          src={docPreview}
                          alt="Document preview"
                          className="img-fluid"
                        />
                      ) : (
                        <p className="font-12 text-secondary mb-0 pt-1">
                          <Paperclip size={14} />&nbsp;
                          <a href={docPreview} target="_blank" rel="noreferrer">Open document</a>
                        </p>
                      )
                    )}
                  </div>
                </div>
                <div className="col-12 pt-3">
                  <FileInput
                    label="Upload Aadhar Card (Back)"
                    name="serviceman_document_2"
                    control={control}
                    error={(errors as any).serviceman_document_2?.message as string}
                  />
                  <div className="col-12 pt-2" style={{ textAlign: "center" }}>
                    {docPreview2 && (
                      /\.(jpe?g|png|gif|webp|bmp|pdf)$/i.test(docPreview2) ? (
                        <img
                          style={{ height: "120px", width: "240px", objectFit: "contain" }}
                          src={docPreview2}
                          alt="Document 2 preview"
                          className="img-fluid"
                        />
                      ) : (
                        <p className="font-12 text-secondary mb-0 pt-1">
                          <Paperclip size={14} />&nbsp;
                          <a href={docPreview2} target="_blank" rel="noreferrer">Open document</a>
                        </p>
                      )
                    )}
                  </div>
                </div>
                <div className="col-12 pt-3">
                  <FileInput
                    label="Upload Driving License"
                    name="serviceman_document_3"
                    control={control}
                    error={(errors as any).serviceman_document_3?.message as string}
                  />
                  <div className="col-12 pt-2" style={{ textAlign: "center" }}>
                    {docPreview3 && (
                      /\.(jpe?g|png|gif|webp|bmp|pdf)$/i.test(docPreview3) ? (
                        <img
                          style={{ height: "120px", width: "240px", objectFit: "contain" }}
                          src={docPreview3}
                          alt="Document 3 preview"
                          className="img-fluid"
                        />
                      ) : (
                        <p className="font-12 text-secondary mb-0 pt-1">
                          <Paperclip size={14} />&nbsp;
                          <a href={docPreview3} target="_blank" rel="noreferrer">Open document</a>
                        </p>
                      )
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
          </div>
        </div>
       

        <div className="row  pt-3">
          <div className="col-12">
            <button
              onClick={handleSubmit(onSubmit)}
              disabled={loading}
              className="fill"
            >
              {loading ? "Loading..." : "Update Profile"}
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditServicemen;
